﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class 前台 : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["IsMemberLogin"] == null)
        {
            MenuMemberLogout.Visible = true;
            PanelMemberLogout.Visible = true ;
            MenuMemberLogin.Visible = false;
            PanelMemberLogin.Visible = false;
        }
        else
        {
            MenuMemberLogout.Visible = false;
            PanelMemberLogout.Visible = false;
            MenuMemberLogin.Visible = true;
            PanelMemberLogin.Visible = true;
        }
    }
    protected void btnMemberLogout_Click(object sender, EventArgs e)
    {
        Session.Clear();
        Response.Redirect("Login.aspx");
    }
}
